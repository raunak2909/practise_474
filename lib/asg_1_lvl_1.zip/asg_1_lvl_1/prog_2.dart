/// Ques 2 :
void main(){




}