/// Ques
void main(){




}